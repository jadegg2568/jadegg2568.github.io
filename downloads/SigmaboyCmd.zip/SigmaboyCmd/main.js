register("chat", (chatType, rank, player, message, event) => {
  if (chatType != "Party" && chatType != "Компания") {
    return;
  }
  
  if (!message.startsWith("!")) {
    return;
  }
  
  let parts = message.split(" ");
  let cmd = parts[0];
  let args = parts.slice(1).join(" ");

  if (cmd == "!sigmaboy") {
    let chance = Math.random();
    let username = args.length == 0 ? player : args[0];

    ChatLib.chat(`/pc ${username} is a ${Math.round(chance * 100)}% sigmaboy!`);
  }
}).setCriteria("${chatType} > ${rank} ${player}: ${message}");
